# 订餐管理系统

这是一个使用 Flask 框架开发的订餐管理系统。

## 功能特点

- 用户注册和登录
- 用户角色管理（普通用户和管理员）
- 菜品管理
- 订单管理
- 个人信息管理

## 安装说明

1. 克隆项目到本地：
```bash
git clone <repository-url>
cd ordersystem
```

2. 创建并激活虚拟环境：
```bash
# 使用 venv（Python 3.3+）
python -m venv venv
source venv/bin/activate  # Linux/Mac
# 或
venv\Scripts\activate  # Windows
```

3. 安装依赖包：
```bash
pip install -r requirements.txt
```

## 运行应用

1. 确保你在项目根目录下并已激活虚拟环境

2. 运行 Flask 应用：
```bash
python app.py
```

3. 在浏览器中访问：
```
http://127.0.0.1:5000
```

## 项目结构

```
ordersystem/
│
├── app.py              # 主应用文件
├── requirements.txt    # 项目依赖
│
├── templates/          # HTML 模板
│   ├── base.html      # 基础模板
│   ├── index.html     # 首页
│   ├── login.html     # 登录页
│   └── register.html  # 注册页
│
└── static/            # 静态文件（CSS、JS、图片等）
```

## 技术栈

- Python 3.8+
- Flask
- SQLAlchemy
- Flask-Login
- Flask-WTF
- Bootstrap 5

## 开发说明

- 数据库使用 SQLite，数据库文件会自动创建在项目根目录下
- 使用 Flask-Login 处理用户认证
- 使用 Flask-WTF 处理表单
- 使用 Bootstrap 5 构建响应式界面

## 注意事项

- 首次运行时会自动创建数据库
- 默认情况下，第一个注册的用户不会自动成为管理员
- 要创建管理员账户，需要手动修改数据库或通过管理命令创建 